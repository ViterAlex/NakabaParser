﻿using System;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using SiteParser.Interfaces;

namespace SiteParser
{
    public class PageLoader : IPageLoader
    {
        private int _currentPage;

        private int _totalPages;

        /// <summary>
        ///     Событие, возникающее при загрузке страницы
        /// </summary>
        public event EventHandler<PageLoadedEventArgs> PageLoaded;

        /// <summary>
        ///     Номер текущей загружаемой страницы
        /// </summary>
        public int CurrentPage
        {
            get { return _currentPage; }
            set
            {
                _currentPage = value;
                if (_currentPage == _totalPages)
                {
                    LoadingEnded?.Invoke(this, new EventArgs());
                }
            }
        }

        /// <summary>
        ///     Общее количество страниц
        /// </summary>
        public int TotalPages
        {
            get { return _totalPages; }
            set
            {
                _totalPages = value;
                if (_currentPage == _totalPages)
                {
                    LoadingEnded?.Invoke(this, new EventArgs());
                }
            }
        }

        /// <summary>
        ///     Парсер объявлений
        /// </summary>
        public IAnnonceParser Parser { get; set; }

        /// <summary>
        ///     Метод осуществляет загрузку страниц
        /// </summary>
        /// <param name="parser">Парсер используемый для парсинга объявлений</param>
        /// <param name="pageUrl">Адрес страницы</param>
        public void LoadPage(IAnnonceParser parser, string pageUrl)
        {
            Parser = parser;
            LoadPage(pageUrl);
        }

        /// <summary>
        ///     Событие, возникающее при окончании загрузки страниц
        /// </summary>
        public event EventHandler LoadingEnded;


        /// <summary>
        ///     Найденное количество объявлений
        /// </summary>
        /// <param name="pageHtml">Код страницы</param>
        private int GetAnnonceCount(string pageHtml)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(pageHtml);
            var result = doc.DocumentNode.SelectSingleNode(".//div[@class='add-find']").InnerText;
            return int.Parse(result.Substring(result.LastIndexOf(':') + 1));
        }

        /// <summary>
        ///     Номер текущей страницы выдачи
        /// </summary>
        /// <param name="pageHtml">Код страницы</param>
        private int GetCurrentPage(string pageHtml)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(pageHtml);
            var result =
                doc.DocumentNode.SelectNodes(".//div[@class='objav-pages']/a[@class='current']")
                   .Select(n => n.InnerText)
                   .Min();
            return int.Parse(result);
        }

        /// <summary>
        ///     Получение адреса следующей страницы
        /// </summary>
        /// <param name="pageUrl">Адрес текущей страницы</param>
        /// <returns>Адрес для загрузки следующей страницы</returns>
        /// <remarks>
        ///     Функция проверяет в строке наличие токена "page=НомерСтраницы".
        ///     Если такой токен найден, то определяется номер страницы и вычисляется следующий.
        ///     Если не найден, то страница считается первой.
        /// </remarks>
        private static string GetNextPageUrl(string pageUrl)
        {
            const string pageToken = "page=";
            //Если в адресе нет токена текущей страницы
            if (pageUrl.IndexOf($"{pageToken}", StringComparison.InvariantCultureIgnoreCase) == -1)
            {
                //то возвращаем адрес на вторую страницу
                return $"{pageUrl}&{pageToken}2";
            }
            //Иначе выполняем поиск токена и замену номера страницы
            string[] tokens = pageUrl.Split('&');
            return tokens.Aggregate((first, second) =>
            {
                int pageNum;
                if (first.StartsWith(pageToken))
                {
                    pageNum = int.Parse(first.Substring(pageToken.Length));
                    return $"{pageToken}{pageNum + 1}&{second}";
                }
                if (second.StartsWith(pageToken))
                {
                    pageNum = int.Parse(second.Substring(pageToken.Length));
                    return $"{first}&{pageToken}{pageNum + 1}";
                }
                return $"{first}&{second}";
            });
        }

        /// <summary>
        ///     Количество страниц выдачи поиска
        /// </summary>
        private int GetPagesCount(string pageHtml)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(pageHtml);
            var result = doc.DocumentNode.SelectNodes(".//div[@class='objav-pages']/a").Select(n =>
            {
                int num;
                int.TryParse(n.InnerText, NumberStyles.Integer, CultureInfo.InvariantCulture, out num);
                return num.ToString(CultureInfo.InvariantCulture);
            }).Max(s => int.Parse(s, CultureInfo.InvariantCulture));
            return result;
        }

        private void LoadPage(string pageUrl)
        {
            using (var client = new WebClient())
            {
                client.Encoding = Encoding.UTF8;
                Task<string> t = client.DownloadStringTaskAsync(pageUrl);
                t.ContinueWith(s => OnPageLoaded(t.Result, pageUrl));
            }
        }

        /// <summary>
        ///     Метод обрабатывающий загрузку страницы
        /// </summary>
        /// <param name="pageHtml">Код загруженной страницы</param>
        /// <param name="pageUrl">Адрес страницы</param>
        private void OnPageLoaded(string pageHtml, string pageUrl)
        {
            TotalPages = GetPagesCount(pageHtml);
            CurrentPage = GetCurrentPage(pageHtml);
            var totalAnnonces = GetAnnonceCount(pageHtml);
            PageLoaded?.Invoke(this, new PageLoadedEventArgs(CurrentPage, TotalPages, totalAnnonces));

            Parser.Parse(pageHtml);

            if (CurrentPage < TotalPages)
            {
                LoadPage(GetNextPageUrl(pageUrl));
            }
        }
    }
}